/**
 * VideoPlayer class for handling both HLS and RTMP streams
 * with error handling and fallback options
 */
class VideoPlayer {
    /**
     * Initialize the video player
     * @param {Object} config - Configuration options
     * @param {string} config.videoElementId - ID of the video element
     * @param {string} config.streamUrl - URL of the stream to play
     * @param {string} config.streamType - Type of stream (hls or rtmp)
     * @param {boolean} config.useProxy - Whether to use the proxy for HLS streams
     * @param {string} config.proxyUrl - Base URL for the proxy endpoint
     */
    constructor(config) {
        this.videoElementId = config.videoElementId;
        this.streamUrl = config.streamUrl;
        this.streamType = config.streamType.toLowerCase();
        this.useProxy = config.useProxy;
        this.proxyUrl = config.proxyUrl;
        
        this.videoElement = document.getElementById(this.videoElementId);
        this.loadingOverlay = document.getElementById('loading-overlay');
        this.errorOverlay = document.getElementById('error-overlay');
        this.errorMessage = document.getElementById('error-message');
        this.currentTimeDisplay = document.getElementById('current-time');
        this.durationDisplay = document.getElementById('duration');
        
        this.hls = null;
        this.isPlaying = false;
        this.hasError = false;
        
        // Bind methods
        this.init = this.init.bind(this);
        this.play = this.play.bind(this);
        this.pause = this.pause.bind(this);
        this.toggleMute = this.toggleMute.bind(this);
        this.isMuted = this.isMuted.bind(this);
        this.toggleFullscreen = this.toggleFullscreen.bind(this);
        this.reload = this.reload.bind(this);
        this.handleError = this.handleError.bind(this);
        this.setupHlsStream = this.setupHlsStream.bind(this);
        this.setupRtmpStream = this.setupRtmpStream.bind(this);
        this.updateTimeDisplay = this.updateTimeDisplay.bind(this);
        this.formatTime = this.formatTime.bind(this);
    }
    
    /**
     * Initialize the video player
     */
    init() {
        console.log(`Initializing player for ${this.streamType} stream: ${this.streamUrl}`);
        
        // Set up event listeners
        this.videoElement.addEventListener('playing', () => {
            this.isPlaying = true;
            this.hideLoading();
        });
        
        this.videoElement.addEventListener('pause', () => {
            this.isPlaying = false;
        });
        
        this.videoElement.addEventListener('timeupdate', this.updateTimeDisplay);
        
        this.videoElement.addEventListener('durationchange', () => {
            if (!isNaN(this.videoElement.duration)) {
                this.durationDisplay.textContent = this.formatTime(this.videoElement.duration);
            }
        });
        
        this.videoElement.addEventListener('error', (e) => {
            console.error('Video element error:', e);
            this.handleError('Failed to load video. Please check the URL and try again.');
        });
        
        // Initialize based on stream type
        if (this.streamType === 'hls') {
            this.setupHlsStream();
        } else if (this.streamType === 'rtmp') {
            this.setupRtmpStream();
        } else {
            this.handleError(`Unsupported stream type: ${this.streamType}`);
        }
    }
    
    /**
     * Set up an HLS stream using hls.js
     */
    setupHlsStream() {
        // Use the proxy URL if enabled
        const streamUrl = this.useProxy ? 
            `${this.proxyUrl}${encodeURIComponent(this.streamUrl)}` : 
            this.streamUrl;
        
        // Check if HLS.js is supported
        if (Hls.isSupported()) {
            console.log('Using HLS.js for playback');
            
            // Clean up any previous HLS instance
            if (this.hls) {
                this.hls.destroy();
            }
            
            // Create a new HLS instance
            this.hls = new Hls({
                debug: false,
                enableWorker: true,
                lowLatencyMode: true,
                backBufferLength: 90
            });
            
            // Handle HLS events
            this.hls.on(Hls.Events.MEDIA_ATTACHED, () => {
                console.log('HLS.js attached to video element');
                this.hls.loadSource(streamUrl);
            });
            
            this.hls.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
                console.log(`Manifest loaded, found ${data.levels.length} quality levels`);
                this.play();
            });
            
            this.hls.on(Hls.Events.ERROR, (event, data) => {
                console.error('HLS error:', data);
                if (data.fatal) {
                    switch(data.type) {
                        case Hls.ErrorTypes.NETWORK_ERROR:
                            console.log('Network error, trying to recover...');
                            this.hls.startLoad();
                            break;
                        case Hls.ErrorTypes.MEDIA_ERROR:
                            console.log('Media error, trying to recover...');
                            this.hls.recoverMediaError();
                            break;
                        default:
                            // Cannot recover, destroy and recreate
                            this.hls.destroy();
                            this.handleError('Failed to load HLS stream. The stream might be unavailable or there could be network issues.');
                            break;
                    }
                }
            });
            
            // Attach HLS to the video element
            this.hls.attachMedia(this.videoElement);
        } 
        // For browsers that natively support HLS (like Safari)
        else if (this.videoElement.canPlayType('application/vnd.apple.mpegurl')) {
            console.log('Using native HLS support for playback');
            this.videoElement.src = streamUrl;
            this.videoElement.addEventListener('loadedmetadata', () => {
                this.play();
            });
        } 
        // No HLS support
        else {
            this.handleError('Your browser does not support HLS streaming. Please try a different browser like Chrome, Firefox, or Safari.');
        }
    }
    
    /**
     * Set up an RTMP stream (requires Flash fallback or specific browser support)
     */
    setupRtmpStream() {
        // RTMP isn't directly supported in HTML5, typically requires a Flash player
        // or conversion to HLS/DASH. For this example, we'll show an error message
        this.handleError('RTMP streaming requires additional plugins or conversion to HLS. Please check the server configuration.');
        
        // In a real-world scenario, you might want to use a player like flowplayer or video.js
        // with their RTMP plugins, or convert the RTMP stream to HLS on the server side
    }
    
    /**
     * Play the video
     */
    play() {
        if (this.hasError) {
            this.reload();
            return;
        }
        
        this.showLoading();
        const playPromise = this.videoElement.play();
        
        if (playPromise !== undefined) {
            playPromise.then(() => {
                this.isPlaying = true;
            }).catch(error => {
                console.error('Play error:', error);
                // Check if it's an autoplay policy error
                if (error.name === 'NotAllowedError') {
                    this.handleError('Autoplay blocked by browser. Please click the play button to start the video.');
                } else {
                    this.handleError('Failed to play the video. Please try again.');
                }
            });
        }
    }
    
    /**
     * Pause the video
     */
    pause() {
        this.videoElement.pause();
        this.isPlaying = false;
    }
    
    /**
     * Toggle mute state
     */
    toggleMute() {
        this.videoElement.muted = !this.videoElement.muted;
    }
    
    /**
     * Check if the video is muted
     */
    isMuted() {
        return this.videoElement.muted;
    }
    
    /**
     * Toggle fullscreen mode
     */
    toggleFullscreen() {
        const container = document.getElementById('video-container');
        
        if (!document.fullscreenElement) {
            if (container.requestFullscreen) {
                container.requestFullscreen();
            } else if (container.webkitRequestFullscreen) { /* Safari */
                container.webkitRequestFullscreen();
            } else if (container.msRequestFullscreen) { /* IE11 */
                container.msRequestFullscreen();
            }
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.webkitExitFullscreen) { /* Safari */
                document.webkitExitFullscreen();
            } else if (document.msExitFullscreen) { /* IE11 */
                document.msExitFullscreen();
            }
        }
    }
    
    /**
     * Reload the stream
     */
    reload() {
        this.hideError();
        this.showLoading();
        this.hasError = false;
        
        if (this.streamType === 'hls') {
            this.setupHlsStream();
        } else if (this.streamType === 'rtmp') {
            this.setupRtmpStream();
        }
    }
    
    /**
     * Handle errors
     * @param {string} message - Error message to display
     */
    handleError(message) {
        console.error(`Player error: ${message}`);
        this.hasError = true;
        this.hideLoading();
        this.errorMessage.textContent = message;
        this.errorOverlay.classList.remove('d-none');
    }
    
    /**
     * Show loading overlay
     */
    showLoading() {
        this.loadingOverlay.classList.remove('d-none');
    }
    
    /**
     * Hide loading overlay
     */
    hideLoading() {
        this.loadingOverlay.classList.add('d-none');
    }
    
    /**
     * Hide error overlay
     */
    hideError() {
        this.errorOverlay.classList.add('d-none');
    }
    
    /**
     * Update the time display
     */
    updateTimeDisplay() {
        if (!isNaN(this.videoElement.currentTime)) {
            this.currentTimeDisplay.textContent = this.formatTime(this.videoElement.currentTime);
        }
    }
    
    /**
     * Format time in seconds to MM:SS format
     * @param {number} timeInSeconds - Time in seconds
     * @returns {string} Formatted time
     */
    formatTime(timeInSeconds) {
        const minutes = Math.floor(timeInSeconds / 60);
        const seconds = Math.floor(timeInSeconds % 60);
        return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    }
}
