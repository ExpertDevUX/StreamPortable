import os
import logging
import requests
from flask import Flask, render_template, request, Response, jsonify, redirect, url_for
from urllib.parse import urlparse

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")

@app.route('/')
def index():
    """Render the main page with video player."""
    return render_template('index.html')

@app.route('/player')
def player():
    """Render the player page with a specific stream URL."""
    stream_url = request.args.get('url', '')
    stream_type = request.args.get('type', 'hls')  # Default to HLS
    embed_mode = request.args.get('embed', '0') == '1'  # Check if embed mode is requested
    
    # Validate the URL
    if stream_url:
        try:
            parsed = urlparse(stream_url)
            if not parsed.scheme or not parsed.netloc:
                return render_template('player.html', error="Invalid URL format", embed_mode=embed_mode)
            
            # For demonstration, you might want to whitelist domains
            # allowed_domains = ['hwosecurity.org', 'your-rtmp-server.com']
            # if parsed.netloc not in allowed_domains:
            #     return render_template('player.html', error="Domain not allowed", embed_mode=embed_mode)
            
            return render_template('player.html', stream_url=stream_url, stream_type=stream_type, embed_mode=embed_mode)
        except Exception as e:
            logger.error(f"Error parsing URL: {e}")
            return render_template('player.html', error="Invalid URL", embed_mode=embed_mode)
    
    return render_template('player.html', embed_mode=embed_mode)

@app.route('/embed')
def embed():
    """Render an embeddable version of the player."""
    stream_url = request.args.get('url', '')
    stream_type = request.args.get('type', 'hls')  # Default to HLS
    
    # Redirect to player with embed parameter
    return redirect(url_for('player', url=stream_url, type=stream_type, embed='1'))

@app.route('/embed-examples')
def embed_examples():
    """Show examples of embedding the player."""
    return render_template('embed-examples.html')

@app.route('/proxy/<path:url>')
def proxy(url):
    """
    Proxy for handling CORS issues with external HLS streams.
    
    This endpoint fetches the requested URL on behalf of the client
    and returns the response with appropriate CORS headers.
    """
    try:
        # Security check: you might want to whitelist domains
        parsed = urlparse(url)
        # allowed_domains = ['hwosecurity.org', 'your-rtmp-server.com']
        # if parsed.netloc not in allowed_domains:
        #     return jsonify({"error": "Domain not allowed"}), 403
        
        # Get query parameters
        params = {k: v for k, v in request.args.items()}
        
        # Forward the request to the target URL
        resp = requests.get(url, params=params, stream=True)
        
        # Create a Flask response with the same content
        response = Response(
            resp.iter_content(chunk_size=10*1024),
            status=resp.status_code,
            content_type=resp.headers.get('Content-Type', 'application/octet-stream')
        )
        
        # Add CORS headers
        response.headers['Access-Control-Allow-Origin'] = '*'
        
        return response
    except Exception as e:
        logger.error(f"Proxy error: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
